<?php
namespace Drupal\d8_training\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\d8_training\Form\WeatherConfigForm;

/**
 * Provides a 'WeatherBlock' Block.
 *
 * @Block(
 *   id = "weather_block",
 *   admin_label = @Translation("Weather Block"),
 * )
 */
class WeatherBlock extends BlockBase {
  public function blockForm($form, FormStateInterface $form_state) {
    $form = array();

    $form['city'] = array(
      '#type' => 'select',
      '#title' => $this->t('City:'),
      '#required' => TRUE,
      '#default_value' => $this->getConfiguration('city'),
      '#options' => array('Select' => '_none', 'mumbai' => 'Mumbai', 'pune' => 'Pune', 'delhi' => 'Delhi', 'london' => 'London'),
    );
    return $form;
  }
  
  /**
   * {@inheritdoc}
   */
  public function blockSubmit($form, FormStateInterface $form_state) {
    $this->setConfiguration(array('city' => $form_state->getValue('city')));
  }
    
  /**
   * {@inheritdoc}
   */
  public function build() {
    $configuration = $this->getConfiguration('city');
    
    return array('#markup' => 'Selected for city: <strong>' . $configuration['city'] . '</strong>. <br/>App Id is: <strong>' . $app_id . '</strong>');
  }
}