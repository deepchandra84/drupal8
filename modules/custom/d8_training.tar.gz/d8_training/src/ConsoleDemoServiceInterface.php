<?php

namespace Drupal\d8_training;

/**
 * Interface ConsoleDemoServiceInterface.
 *
 * @package Drupal\d8_training
 */
interface ConsoleDemoServiceInterface {


}
