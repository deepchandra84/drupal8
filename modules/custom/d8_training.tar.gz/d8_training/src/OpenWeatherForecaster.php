<?php

namespace Drupal\d8_training;

use Drupal\Core\Config\ConfigFactory;
class OpenWeatherForecaster {
  private $configFactory;
  
  public function __construct(ConfigFactory $configFactory) {
    $this->configFactory = $configFactory;
  }
  
  public function fetchWeatherData($city_name) {
    
  }
}